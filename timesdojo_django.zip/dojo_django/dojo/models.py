"""
dojo/models.py
--------------
All database models for TimesTable Dojo.

Model hierarchy:
  User  (extends AbstractUser — so we get auth, permissions, is_staff for free)
    ├── BeltProgress   (one per belt per user — 9 rows created on register)
    ├── FactMemory     (one per multiplication fact per user — up to 400 rows)
    ├── TrainingSession (one per completed game session)
    ├── UserBadge      (junction: user × badge)
    ├── Streak         (one row per user, updated daily)
    └── TutorRequest   (student → tutor connection request)

Run after changes:
    python manage.py makemigrations
    python manage.py migrate
"""

import json
from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils import timezone


# ─────────────────────────────────────────────────────────────────────────────
# CONSTANTS — belt ordering used across the whole codebase
# ─────────────────────────────────────────────────────────────────────────────
BELT_CHOICES = [
    ("white",  "White Belt"),
    ("yellow", "Yellow Belt"),
    ("blue",   "Blue Belt"),
    ("red",    "Red Belt"),
    ("black",  "Black Belt"),
    ("brown",  "Brown Belt"),
    ("purple", "Purple Belt"),
    ("gold",   "Gold Belt"),
    ("master", "Master Belt"),
]

BELT_ORDER = [b[0] for b in BELT_CHOICES]   # ['white', 'yellow', ...]

ROLE_CHOICES = [
    ("student", "Student"),
    ("tutor",   "Tutor"),
    ("admin",   "Admin"),
]

TUTOR_SPEC_CHOICES = [
    ("primary", "Primary (Grades 1–4)"),
    ("junior",  "Junior (Grades 5–7)"),
    ("senior",  "Senior (Grades 8–10)"),
    ("all",     "All Levels"),
]


# ─────────────────────────────────────────────────────────────────────────────
# USER — extends Django's AbstractUser so we keep hashed passwords, sessions,
#         admin login, is_active, date_joined, last_login for free.
# ─────────────────────────────────────────────────────────────────────────────
class User(AbstractUser):
    """
    Custom user model.  We extend AbstractUser rather than AbstractBaseUser
    so we keep all of Django's auth machinery (groups, permissions, admin).

    Extra fields beyond AbstractUser:
      role     — student | tutor | admin
      county   — Kenyan county (for leaderboard scoping)
      school   — school name
      spec     — tutor specialisation (blank for students)
      is_paid  — has paid subscription
    """

    role    = models.CharField(max_length=10, choices=ROLE_CHOICES, default="student", db_index=True)
    county  = models.CharField(max_length=100, blank=True)
    school  = models.CharField(max_length=200, blank=True)
    spec    = models.CharField(max_length=20, choices=TUTOR_SPEC_CHOICES, blank=True)
    is_paid = models.BooleanField(default=False, db_index=True)

    # AbstractUser already has:
    #   username, first_name, last_name, email,
    #   is_active, is_staff, is_superuser,
    #   date_joined, last_login,
    #   groups, user_permissions

    class Meta:
        verbose_name = "User"
        verbose_name_plural = "Users"
        ordering = ["-date_joined"]

    def __str__(self):
        return f"{self.get_full_name()} ({self.role})"

    # ── helpers ──────────────────────────────────────────────────────────────

    @property
    def display_name(self):
        return self.get_full_name() or self.username

    @property
    def current_belt_idx(self):
        """Index of the highest belt the user has passed, or 0."""
        passed = (
            self.belt_progress
            .filter(passed=True)
            .values_list("belt_id", flat=True)
        )
        highest = -1
        for belt_id in passed:
            idx = BELT_ORDER.index(belt_id) if belt_id in BELT_ORDER else -1
            highest = max(highest, idx)
        return max(0, min(highest + 1, len(BELT_ORDER) - 1))

    @property
    def active_belt_id(self):
        return BELT_ORDER[self.current_belt_idx]

    def get_leaderboard_score(self):
        return self.training_sessions.aggregate(
            total=models.Sum("correct")
        )["total"] or 0


# ─────────────────────────────────────────────────────────────────────────────
# BELT PROGRESS
# ─────────────────────────────────────────────────────────────────────────────
class BeltProgress(models.Model):
    """
    One row per (user, belt) pair — 9 rows created automatically when a
    student registers via the post_save signal in signals.py.

    levels_done: JSON list of table numbers the student has cleared
    e.g. [2, 5] means they completed the ×2 and ×5 levels within this belt.
    """

    STATUS_CHOICES = [
        ("locked", "Locked"),
        ("active", "Active"),
        ("passed", "Passed"),
    ]

    user        = models.ForeignKey(User, on_delete=models.CASCADE, related_name="belt_progress")
    belt_id     = models.CharField(max_length=10, choices=BELT_CHOICES, db_index=True)
    status      = models.CharField(max_length=10, choices=STATUS_CHOICES, default="locked")
    passed      = models.BooleanField(default=False)
    attempts    = models.PositiveIntegerField(default=0)
    best_acc    = models.FloatField(default=0.0)        # 0.0–1.0
    levels_done = models.JSONField(default=list)        # [2, 5, 10, 11]
    updated_at  = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = [("user", "belt_id")]
        ordering = ["user", models.Case(
            *[models.When(belt_id=bid, then=i) for i, bid in enumerate(BELT_ORDER)],
            output_field=models.IntegerField()
        )]
        verbose_name = "Belt Progress"
        verbose_name_plural = "Belt Progress"

    def __str__(self):
        return f"{self.user.display_name} — {self.get_belt_id_display()} ({self.status})"

    @property
    def belt_index(self):
        return BELT_ORDER.index(self.belt_id) if self.belt_id in BELT_ORDER else 0


# ─────────────────────────────────────────────────────────────────────────────
# FACT MEMORY
# ─────────────────────────────────────────────────────────────────────────────
class FactMemory(models.Model):
    """
    Tracks a user's history with every individual multiplication fact.
    One row per (user, a, b).  Max 400 rows per user (20×20 grid).

    total_time_ms: cumulative milliseconds spent answering this fact.
    Divide by seen to get average response time.
    """

    user          = models.ForeignKey(User, on_delete=models.CASCADE, related_name="fact_memory")
    a             = models.PositiveSmallIntegerField()    # multiplicand  (1–20)
    b             = models.PositiveSmallIntegerField()    # multiplier    (1–20)
    seen          = models.PositiveIntegerField(default=0)
    correct       = models.PositiveIntegerField(default=0)
    total_time_ms = models.PositiveBigIntegerField(default=0)

    class Meta:
        unique_together = [("user", "a", "b")]
        verbose_name = "Fact Memory"
        verbose_name_plural = "Fact Memory"

    def __str__(self):
        return f"{self.user.display_name}: {self.a}×{self.b} ({self.accuracy_pct}%)"

    @property
    def accuracy(self):
        """Float 0.0–1.0"""
        return self.correct / self.seen if self.seen else 0.0

    @property
    def accuracy_pct(self):
        return round(self.accuracy * 100)

    @property
    def avg_time_ms(self):
        return self.total_time_ms / self.seen if self.seen else 0

    @property
    def performance_class(self):
        """Returns css class key: fast | good | slow | weak | unseen"""
        if not self.seen:
            return "unseen"
        if self.accuracy < 0.5:
            return "weak"
        if self.accuracy < 0.8:
            return "slow"
        if self.avg_time_ms > 8000:
            return "good"
        return "fast"


# ─────────────────────────────────────────────────────────────────────────────
# TRAINING SESSION
# ─────────────────────────────────────────────────────────────────────────────
class TrainingSession(models.Model):
    """
    One row per completed (or abandoned) training session.
    Created when the student finishes or exits a belt attempt.
    """

    user       = models.ForeignKey(User, on_delete=models.CASCADE, related_name="training_sessions")
    belt_id    = models.CharField(max_length=10, choices=BELT_CHOICES)
    passed     = models.BooleanField(default=False)
    accuracy   = models.FloatField(default=0.0)          # 0.0–1.0
    time_used  = models.PositiveIntegerField(default=0)  # seconds
    correct    = models.PositiveIntegerField(default=0)
    total_q    = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ["-created_at"]
        verbose_name = "Training Session"
        verbose_name_plural = "Training Sessions"

    def __str__(self):
        status = "PASS" if self.passed else "FAIL"
        return f"{self.user.display_name} — {self.get_belt_id_display()} [{status}] {self.accuracy_pct}%"

    @property
    def accuracy_pct(self):
        return round(self.accuracy * 100)

    @property
    def time_display(self):
        m, s = divmod(self.time_used, 60)
        return f"{m}:{s:02d}"


# ─────────────────────────────────────────────────────────────────────────────
# BADGE
# ─────────────────────────────────────────────────────────────────────────────
BADGE_CHOICES = [
    ("first_correct", "First Correct"),
    ("white_belt",    "White Belt"),
    ("yellow_belt",   "Yellow Belt"),
    ("blue_belt",     "Blue Belt"),
    ("red_belt",      "Red Belt"),
    ("black_belt",    "Black Belt"),
    ("brown_belt",    "Brown Belt"),
    ("purple_belt",   "Purple Belt"),
    ("gold_belt",     "Gold Belt"),
    ("master_belt",   "Master Belt"),
    ("perfect_belt",  "Perfect Run"),
    ("speed_run",     "Speed Run"),
    ("streak_7",      "Week Warrior"),
    ("century",       "Century"),
]

class UserBadge(models.Model):
    """Junction table: which badges has this user earned, and when."""

    user      = models.ForeignKey(User, on_delete=models.CASCADE, related_name="badges")
    badge_id  = models.CharField(max_length=30, choices=BADGE_CHOICES)
    earned_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = [("user", "badge_id")]
        ordering = ["earned_at"]
        verbose_name = "User Badge"
        verbose_name_plural = "User Badges"

    def __str__(self):
        return f"{self.user.display_name} — {self.get_badge_id_display()}"


# ─────────────────────────────────────────────────────────────────────────────
# STREAK
# ─────────────────────────────────────────────────────────────────────────────
class Streak(models.Model):
    """
    One row per student.  Updated every time they complete a session.
    We check if last_date == yesterday → increment, else reset to 1.
    """

    user      = models.OneToOneField(User, on_delete=models.CASCADE, related_name="streak")
    count     = models.PositiveIntegerField(default=0)
    last_date = models.DateField(null=True, blank=True)

    class Meta:
        verbose_name = "Streak"
        verbose_name_plural = "Streaks"

    def __str__(self):
        return f"{self.user.display_name} — {self.count} days"

    def update(self):
        """
        Call after a student completes any session.
        Returns the new streak count.
        """
        from datetime import date, timedelta
        today = date.today()
        if self.last_date == today:
            return self.count   # already trained today, no change
        yesterday = today - timedelta(days=1)
        self.count = self.count + 1 if self.last_date == yesterday else 1
        self.last_date = today
        self.save(update_fields=["count", "last_date"])
        return self.count


# ─────────────────────────────────────────────────────────────────────────────
# TUTOR REQUEST
# ─────────────────────────────────────────────────────────────────────────────
class TutorRequest(models.Model):
    """
    A student requests coaching from a tutor.
    Tutors accept or reject via their dashboard.
    """

    STATUS_CHOICES = [
        ("pending",  "Pending"),
        ("accepted", "Accepted"),
        ("rejected", "Rejected"),
    ]

    student    = models.ForeignKey(User, on_delete=models.CASCADE, related_name="tutor_requests_sent")
    tutor      = models.ForeignKey(User, on_delete=models.CASCADE, related_name="tutor_requests_received")
    status     = models.CharField(max_length=10, choices=STATUS_CHOICES, default="pending", db_index=True)
    message    = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at"]
        verbose_name = "Tutor Request"
        verbose_name_plural = "Tutor Requests"

    def __str__(self):
        return f"{self.student.display_name} → {self.tutor.display_name} ({self.status})"
