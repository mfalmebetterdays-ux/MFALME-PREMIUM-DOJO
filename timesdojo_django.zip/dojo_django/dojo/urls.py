"""
dojo/urls.py
------------
All URL patterns for the TimesTable Dojo app.

Pattern groups:
  Pages    →  return rendered HTML templates
  API      →  return JSON (consumed by the JS frontend)
  Admin    →  custom admin dashboard (not Django's built-in admin)

Naming convention:
  page names: "dojo:<name>"   e.g. dojo:home, dojo:login
  api  names: "dojo:api-<name>"
  admin names:"dojo:admin-<name>"
"""

from django.urls import path
from . import views

app_name = "dojo"

urlpatterns = [

    # ── HTML PAGES ────────────────────────────────────────────────────────────

    path("",          views.StudentAppView.as_view(),  name="home"),
    path("login/",    views.LoginView.as_view(),        name="login"),
    path("logout/",   views.LogoutView.as_view(),       name="logout"),
    path("register/", views.RegisterView.as_view(),     name="register"),
    path("admin/",    views.AdminAppView.as_view(),     name="admin"),

    # ── AUTH API ──────────────────────────────────────────────────────────────

    path("api/register/",    views.api_register,   name="api-register"),
    path("api/login/",       views.api_login,       name="api-login"),
    path("api/logout/",      views.api_logout,      name="api-logout"),
    path("api/me/",          views.api_me,           name="api-me"),

    # ── STUDENT API ───────────────────────────────────────────────────────────

    path("api/student/profile/",          views.api_student_profile,      name="api-student-profile"),
    path("api/student/belts/",            views.api_student_belts,        name="api-student-belts"),
    path("api/student/belts/update/",     views.api_student_belt_update,  name="api-student-belt-update"),
    path("api/student/session/save/",     views.api_session_save,         name="api-session-save"),
    path("api/student/facts/",            views.api_facts_get,            name="api-facts-get"),
    path("api/student/facts/update/",     views.api_facts_update,         name="api-facts-update"),
    path("api/student/badges/",           views.api_badges,               name="api-badges"),
    path("api/student/streak/",           views.api_streak,               name="api-streak"),
    path("api/student/leaderboard/",      views.api_leaderboard,          name="api-leaderboard"),
    path("api/student/tutors/",           views.api_tutors_search,        name="api-tutors-search"),
    path("api/student/request-tutor/",    views.api_request_tutor,        name="api-request-tutor"),
    path("api/student/my-requests/",      views.api_my_requests,          name="api-my-requests"),

    # ── TUTOR API ─────────────────────────────────────────────────────────────

    path("api/tutor/requests/",           views.api_tutor_requests,       name="api-tutor-requests"),
    path("api/tutor/request/update/",     views.api_tutor_request_update, name="api-tutor-request-update"),

    # ── ADMIN API ─────────────────────────────────────────────────────────────

    path("api/admin/login/",              views.api_admin_login,          name="api-admin-login"),
    path("api/admin/overview/",           views.api_admin_overview,       name="api-admin-overview"),
    path("api/admin/students/",           views.api_admin_students,       name="api-admin-students"),
    path("api/admin/tutors/",             views.api_admin_tutors,         name="api-admin-tutors"),
    path("api/admin/belts/",              views.api_admin_belts,          name="api-admin-belts"),
    path("api/admin/knowledge/",          views.api_admin_knowledge,      name="api-admin-knowledge"),
    path("api/admin/activity/",           views.api_admin_activity,       name="api-admin-activity"),
    path("api/admin/county/",             views.api_admin_county,         name="api-admin-county"),
    path("api/admin/leaderboard/",        views.api_admin_leaderboard,    name="api-admin-leaderboard"),
    path("api/admin/tutor-requests/",     views.api_admin_tutor_requests, name="api-admin-tutor-requests"),
    path("api/admin/user/suspend/",       views.api_admin_suspend,        name="api-admin-suspend"),
    path("api/admin/user/upgrade/",       views.api_admin_upgrade,        name="api-admin-upgrade"),
    path("api/admin/tutor/approve/",      views.api_admin_approve_tutor,  name="api-admin-approve-tutor"),
]
