"""
dojo/views.py
-------------
All views for TimesTable Dojo.

Two kinds of views live here:

1. PAGE VIEWS (class-based)
   Render HTML templates.  The frontend JS then calls the API endpoints
   below to load/save data — so the templates are essentially thin shells
   that load the CSS/JS and let JavaScript do the heavy lifting.

2. API VIEWS (function-based, decorated with @require_POST or @require_GET)
   Return JSON.  No server-side HTML generation for these.
   Pattern:
     - @login_required / @require_role guard access
     - parse JSON body with json_body(request)
     - do DB work
     - return JsonResponse(...)

Helper decorators defined at the top:
  @require_role(role)  — checks request.user.role
  @admin_only          — shorthand for @require_role("admin")
"""

import json
import logging
from functools import wraps

from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.core.paginator import Paginator
from django.db import transaction
from django.db.models import Avg, Count, F, Q, Sum
from django.http import JsonResponse
from django.shortcuts import redirect, render
from django.utils import timezone
from django.views import View
from django.views.decorators.http import require_GET, require_POST
from django.views.decorators.csrf import csrf_exempt

from .models import (
    BELT_ORDER,
    BeltProgress,
    FactMemory,
    Streak,
    TrainingSession,
    TutorRequest,
    User,
    UserBadge,
)

logger = logging.getLogger("dojo")


# ─────────────────────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def json_body(request):
    """Parse JSON request body. Returns dict or empty dict on error."""
    try:
        return json.loads(request.body)
    except (json.JSONDecodeError, ValueError):
        return {}


def ok(data=None, **kwargs):
    payload = {"ok": True}
    if data:
        payload.update(data)
    payload.update(kwargs)
    return JsonResponse(payload)


def err(message, status=400):
    return JsonResponse({"error": message}, status=status)


def user_json(user):
    """Serialize a User to a safe dict for API responses."""
    return {
        "id":         user.pk,
        "email":      user.email,
        "first_name": user.first_name,
        "last_name":  user.last_name,
        "role":       user.role,
        "county":     user.county,
        "school":     user.school,
        "spec":       user.spec,
        "is_paid":    user.is_paid,
        "date_joined": user.date_joined.isoformat(),
    }


def belt_progress_json(bp_qs):
    """Serialize a BeltProgress queryset to {belt_id: {...}} dict."""
    result = {}
    for bp in bp_qs:
        result[bp.belt_id] = {
            "belt_id":     bp.belt_id,
            "status":      bp.status,
            "passed":      bp.passed,
            "attempts":    bp.attempts,
            "best_acc":    bp.best_acc,
            "levels_done": bp.levels_done,
        }
    return result


def require_role(*roles):
    """
    Decorator: user must be logged in AND have one of the given roles.
    Usage:
        @require_role("student")
        @require_role("admin", "tutor")
    """
    def decorator(view_func):
        @wraps(view_func)
        def _wrapped(request, *args, **kwargs):
            if not request.user.is_authenticated:
                return err("Unauthorized", 401)
            if request.user.role not in roles:
                return err("Forbidden", 403)
            return view_func(request, *args, **kwargs)
        return _wrapped
    return decorator


def admin_only(view_func):
    return require_role("admin")(view_func)


def award_badge_if_new(user, badge_id):
    """Award a badge and return True if it's new. False if already earned."""
    _, created = UserBadge.objects.get_or_create(user=user, badge_id=badge_id)
    return created


# ─────────────────────────────────────────────────────────────────────────────
# PAGE VIEWS — render the HTML shells
# ─────────────────────────────────────────────────────────────────────────────

class StudentAppView(View):
    """
    Serves the student single-page application.
    The template contains all HTML/CSS/JS for the student UI.
    It checks auth via the /api/me/ endpoint on page load.
    """
    def get(self, request):
        return render(request, "dojo/student_app.html")


class AdminAppView(View):
    """
    Serves the admin single-page application.
    Auth is handled entirely by the /api/admin/login/ endpoint.
    """
    def get(self, request):
        return render(request, "dojo/admin_app.html")


class LoginView(View):
    """Traditional login page — redirects to / if already logged in."""
    def get(self, request):
        if request.user.is_authenticated:
            return redirect("/")
        return render(request, "dojo/student_app.html")


class RegisterView(View):
    def get(self, request):
        if request.user.is_authenticated:
            return redirect("/")
        return render(request, "dojo/student_app.html")


class LogoutView(View):
    def get(self, request):
        logout(request)
        return redirect("/")


# ─────────────────────────────────────────────────────────────────────────────
# AUTH API
# ─────────────────────────────────────────────────────────────────────────────

@csrf_exempt
@require_POST
def api_register(request):
    data = json_body(request)
    email      = data.get("email", "").strip().lower()
    password   = data.get("password", "")
    first_name = data.get("first_name", "").strip()
    last_name  = data.get("last_name", "").strip()
    role       = data.get("role", "student")
    county     = data.get("county", "")
    school     = data.get("school", "")
    spec       = data.get("spec", "")

    if not email or not password or not first_name:
        return err("Email, password, and first name are required")
    if len(password) < 6:
        return err("Password must be at least 6 characters")
    if role not in ("student", "tutor"):
        return err("Invalid role")
    if User.objects.filter(email=email).exists():
        return err("Email already registered")

    user = User.objects.create_user(
        username=email,          # username = email for simplicity
        email=email,
        password=password,
        first_name=first_name,
        last_name=last_name,
        role=role,
        county=county,
        school=school,
        spec=spec,
    )
    # Signal in signals.py creates BeltProgress + Streak for students

    login(request, user)
    logger.info("New %s registered: %s", role, email)
    return ok(user=user_json(user))


@csrf_exempt
@require_POST
def api_login(request):
    data     = json_body(request)
    email    = data.get("email", "").strip().lower()
    password = data.get("password", "")
    role     = data.get("role")           # optional role filter

    if not email or not password:
        return err("Email and password required")

    user = authenticate(request, username=email, password=password)
    if not user:
        # try with email field in case username differs
        try:
            u = User.objects.get(email=email)
            user = authenticate(request, username=u.username, password=password)
        except User.DoesNotExist:
            pass

    if not user:
        return err("Invalid email or password", 401)
    if not user.is_active:
        return err("Account is suspended", 401)
    if role and user.role != role:
        return err(f"No {role} account found with these credentials", 401)

    login(request, user)
    return ok(user=user_json(user))


@csrf_exempt
@require_POST
def api_logout(request):
    logout(request)
    return ok()


@require_GET
def api_me(request):
    if not request.user.is_authenticated:
        return err("Unauthorized", 401)
    return ok(user=user_json(request.user))


# ─────────────────────────────────────────────────────────────────────────────
# STUDENT API
# ─────────────────────────────────────────────────────────────────────────────

@require_GET
@require_role("student")
def api_student_profile(request):
    user = request.user
    bp   = belt_progress_json(user.belt_progress.all())
    badges = list(user.badges.values_list("badge_id", flat=True))
    facts  = {
        f"{fm.a}x{fm.b}": {
            "a": fm.a, "b": fm.b,
            "seen": fm.seen, "correct": fm.correct,
            "total_time": fm.total_time_ms,
        }
        for fm in user.fact_memory.all()
    }
    streak_obj, _ = Streak.objects.get_or_create(user=user)
    stats = user.training_sessions.aggregate(
        total_sessions=Count("id"),
        total_correct=Sum("correct"),
        total_questions=Sum("total_q"),
        avg_accuracy=Avg("accuracy"),
    )
    return ok(
        user=user_json(user),
        belts=bp,
        badges=badges,
        fact_memory=facts,
        streak=streak_obj.count,
        last_date=streak_obj.last_date.isoformat() if streak_obj.last_date else None,
        stats={k: (round(v, 4) if isinstance(v, float) else v or 0) for k, v in stats.items()},
    )


@require_GET
@require_role("student")
def api_student_belts(request):
    bp = belt_progress_json(request.user.belt_progress.all())
    return ok(belts=bp)


@csrf_exempt
@require_POST
@require_role("student")
def api_student_belt_update(request):
    data      = json_body(request)
    belt_id   = data.get("belt_id", "")
    if belt_id not in BELT_ORDER:
        return err("Invalid belt_id")

    bp, _ = BeltProgress.objects.get_or_create(
        user=request.user, belt_id=belt_id,
        defaults={"status": "locked"},
    )
    passed      = data.get("passed", False)
    bp.status      = data.get("status", bp.status)
    bp.passed      = passed
    bp.attempts    = data.get("attempts", bp.attempts)
    bp.best_acc    = max(bp.best_acc, data.get("best_acc", 0))
    bp.levels_done = data.get("levels_done", bp.levels_done)
    bp.save()

    # Unlock next belt when passed
    if passed:
        idx = BELT_ORDER.index(belt_id)
        if idx + 1 < len(BELT_ORDER):
            next_id = BELT_ORDER[idx + 1]
            BeltProgress.objects.filter(
                user=request.user, belt_id=next_id, status="locked"
            ).update(status="active")

    bp_all = belt_progress_json(request.user.belt_progress.all())
    return ok(belts=bp_all)


@csrf_exempt
@require_POST
@require_role("student")
def api_session_save(request):
    data    = json_body(request)
    user    = request.user
    belt_id = data.get("belt_id", "white")
    passed  = bool(data.get("passed", False))
    accuracy = float(data.get("accuracy", 0))
    time_used = int(data.get("time_used", 0))
    correct   = int(data.get("correct", 0))
    total_q   = int(data.get("total_q", 0))

    with transaction.atomic():
        TrainingSession.objects.create(
            user=user, belt_id=belt_id, passed=passed,
            accuracy=accuracy, time_used=time_used,
            correct=correct, total_q=total_q,
        )
        # Update streak
        streak_obj, _ = Streak.objects.select_for_update().get_or_create(user=user)
        new_streak = streak_obj.update()

        # Evaluate badges
        new_badges = []
        total_correct = user.training_sessions.aggregate(s=Sum("correct"))["s"] or 0

        def _award(bid):
            if award_badge_if_new(user, bid):
                new_badges.append(bid)

        if total_correct >= 1:
            _award("first_correct")
        if passed:
            _award(f"{belt_id}_belt")
            if accuracy >= 1.0:
                _award("perfect_belt")
            remaining = (belt_id == "white" and time_used < (5 * 60 - 120))
            if time_used > 0:
                belt_minutes = {"white":5,"yellow":7,"blue":9,"red":11,"black":13,
                                "brown":15,"purple":17,"gold":19,"master":21}
                allowed = belt_minutes.get(belt_id, 5) * 60
                if allowed - time_used >= 120:
                    _award("speed_run")
        if new_streak >= 7:
            _award("streak_7")
        if total_correct >= 100:
            _award("century")

    return ok(streak=new_streak, new_badges=new_badges)


@require_GET
@require_role("student")
def api_facts_get(request):
    facts = {
        f"{fm.a}x{fm.b}": {
            "a": fm.a, "b": fm.b,
            "seen": fm.seen, "correct": fm.correct,
            "total_time": fm.total_time_ms,
        }
        for fm in request.user.fact_memory.all()
    }
    return ok(facts=facts)


@csrf_exempt
@require_POST
@require_role("student")
def api_facts_update(request):
    data  = json_body(request)
    facts = data.get("facts", [])
    user  = request.user

    with transaction.atomic():
        for f in facts:
            a = int(f.get("a", 0))
            b = int(f.get("b", 0))
            if not (1 <= a <= 20 and 1 <= b <= 20):
                continue
            correct_val = 1 if f.get("correct") else 0
            time_ms = int(f.get("time_ms", 0))

            # Use update_or_create so we never double-insert
            FactMemory.objects.update_or_create(
                user=user, a=a, b=b,
                defaults={},
            )
            # Atomic increment using F() expressions — safe under concurrency
            FactMemory.objects.filter(user=user, a=a, b=b).update(
                seen=F("seen") + 1,
                correct=F("correct") + correct_val,
                total_time_ms=F("total_time_ms") + time_ms,
            )
    return ok()


@require_GET
@require_role("student")
def api_badges(request):
    badges = list(request.user.badges.values_list("badge_id", flat=True))
    return ok(badges=badges)


@require_GET
@require_role("student")
def api_streak(request):
    streak_obj, _ = Streak.objects.get_or_create(user=request.user)
    return ok(
        streak=streak_obj.count,
        last_date=streak_obj.last_date.isoformat() if streak_obj.last_date else None,
    )


@require_GET
@require_role("student")
def api_leaderboard(request):
    scope = request.GET.get("scope", "national")
    user  = request.user

    qs = User.objects.filter(role="student", is_active=True)
    if scope == "school" and user.school:
        qs = qs.filter(school=user.school)
    elif scope == "county" and user.county:
        qs = qs.filter(county=user.county)

    # Annotate with score (total correct answers)
    qs = qs.annotate(
        score=Sum("training_sessions__correct"),
        sessions=Count("training_sessions"),
    ).order_by(F("score").desc(nulls_last=True))[:50]

    entries = []
    for u in qs:
        passed_belts = list(
            u.belt_progress.filter(passed=True)
            .values_list("belt_id", flat=True)
        )
        highest = max(
            (BELT_ORDER.index(b) for b in passed_belts if b in BELT_ORDER),
            default=-1,
        )
        entries.append({
            "id":      u.pk,
            "name":    u.get_full_name() or u.username,
            "school":  u.school,
            "county":  u.county,
            "score":   u.score or 0,
            "belt_idx": highest,
            "sessions": u.sessions or 0,
        })

    return ok(entries=entries, scope=scope)


@require_GET
@require_role("student")
def api_tutors_search(request):
    name_q   = request.GET.get("name", "").strip().lower()
    county_q = request.GET.get("county", "").strip().lower()
    spec_q   = request.GET.get("spec", "").strip().lower()

    qs = User.objects.filter(role="tutor", is_active=True)
    if name_q:
        qs = qs.filter(
            Q(first_name__icontains=name_q) | Q(last_name__icontains=name_q)
        )
    if county_q:
        qs = qs.filter(county__iexact=county_q)
    if spec_q:
        qs = qs.filter(spec__icontains=spec_q)

    tutors = [
        {
            "id":      t.pk,
            "name":    t.get_full_name(),
            "spec":    t.get_spec_display(),
            "county":  t.county,
            "school":  t.school,
            "rating":  4.7,        # placeholder — add a Rating model later
            "available": True,
        }
        for t in qs[:50]
    ]
    return ok(tutors=tutors)


@csrf_exempt
@require_POST
@require_role("student")
def api_request_tutor(request):
    data     = json_body(request)
    tutor_id = data.get("tutor_id")
    message  = data.get("message", "")

    try:
        tutor = User.objects.get(pk=tutor_id, role="tutor", is_active=True)
    except User.DoesNotExist:
        return err("Tutor not found")

    req, created = TutorRequest.objects.get_or_create(
        student=request.user,
        tutor=tutor,
        defaults={"message": message},
    )
    if not created:
        return err("You have already sent a request to this tutor")

    return ok(request_id=req.pk)


@require_GET
@require_role("student")
def api_my_requests(request):
    reqs = TutorRequest.objects.filter(
        student=request.user
    ).select_related("tutor").order_by("-created_at")

    data = [
        {
            "id":         r.pk,
            "tutor_id":   r.tutor.pk,
            "tutor_name": r.tutor.get_full_name(),
            "status":     r.status,
            "created_at": r.created_at.isoformat(),
        }
        for r in reqs
    ]
    return ok(requests=data)


# ─────────────────────────────────────────────────────────────────────────────
# TUTOR API
# ─────────────────────────────────────────────────────────────────────────────

@require_GET
@require_role("tutor")
def api_tutor_requests(request):
    reqs = TutorRequest.objects.filter(
        tutor=request.user
    ).select_related("student").order_by("-created_at")

    data = [
        {
            "id":           r.pk,
            "student_id":   r.student.pk,
            "student_name": r.student.get_full_name(),
            "school":       r.student.school,
            "county":       r.student.county,
            "status":       r.status,
            "message":      r.message,
            "created_at":   r.created_at.isoformat(),
        }
        for r in reqs
    ]
    return ok(requests=data)


@csrf_exempt
@require_POST
@require_role("tutor")
def api_tutor_request_update(request):
    data       = json_body(request)
    request_id = data.get("request_id")
    status     = data.get("status")

    if status not in ("accepted", "rejected"):
        return err("status must be accepted or rejected")

    updated = TutorRequest.objects.filter(
        pk=request_id, tutor=request.user
    ).update(status=status)

    if not updated:
        return err("Request not found", 404)
    return ok()


# ─────────────────────────────────────────────────────────────────────────────
# ADMIN API
# ─────────────────────────────────────────────────────────────────────────────

@csrf_exempt
@require_POST
def api_admin_login(request):
    """Separate login endpoint for the admin SPA."""
    data     = json_body(request)
    email    = data.get("email", "").strip().lower()
    password = data.get("password", "")

    try:
        u = User.objects.get(email=email, role="admin")
    except User.DoesNotExist:
        return err("Invalid credentials", 401)

    user = authenticate(request, username=u.username, password=password)
    if not user:
        return err("Invalid credentials", 401)

    login(request, user)
    return ok(user=user_json(user))


@require_GET
@admin_only
def api_admin_overview(request):
    total_students  = User.objects.filter(role="student", is_active=True).count()
    total_tutors    = User.objects.filter(role="tutor",   is_active=True).count()
    paid_students   = User.objects.filter(role="student", is_paid=True, is_active=True).count()
    active_schools  = User.objects.filter(role="student", is_active=True).exclude(school="").values("school").distinct().count()
    total_belts     = BeltProgress.objects.filter(passed=True).count()
    total_sessions  = TrainingSession.objects.count()
    total_q         = TrainingSession.objects.aggregate(s=Sum("total_q"))["s"] or 0
    avg_acc         = TrainingSession.objects.aggregate(a=Avg("accuracy"))["a"] or 0

    return ok(
        total_students=total_students,
        total_tutors=total_tutors,
        paid_students=paid_students,
        active_schools=active_schools,
        total_belts=total_belts,
        total_sessions=total_sessions,
        total_questions=total_q,
        avg_accuracy=round(avg_acc * 100, 1),
        revenue_total=paid_students * 5,
        revenue_month=paid_students * 5,
    )


@require_GET
@admin_only
def api_admin_students(request):
    county = request.GET.get("county", "")
    paid   = request.GET.get("paid", "")

    qs = User.objects.filter(role="student", is_active=True)
    if county:
        qs = qs.filter(county=county)
    if paid == "1":
        qs = qs.filter(is_paid=True)
    elif paid == "0":
        qs = qs.filter(is_paid=False)

    qs = qs.annotate(
        sessions=Count("training_sessions"),
        total_correct=Sum("training_sessions__correct"),
        avg_acc=Avg("training_sessions__accuracy"),
    ).prefetch_related("belt_progress", "badges")[:200]

    students = []
    for u in qs:
        passed_belts = [bp.belt_id for bp in u.belt_progress.all() if bp.passed]
        highest = max(
            (BELT_ORDER.index(b) for b in passed_belts if b in BELT_ORDER),
            default=-1,
        )
        streak_obj = getattr(u, "_streak_cache", None) or Streak.objects.filter(user=u).first()
        students.append({
            **user_json(u),
            "sessions":     u.sessions or 0,
            "total_correct": u.total_correct or 0,
            "accuracy":     round((u.avg_acc or 0) * 100, 1),
            "belt_idx":     highest,
            "belt_name":    f"{BELT_ORDER[highest].title()} Belt" if highest >= 0 else "No Belt",
            "streak":       streak_obj.count if streak_obj else 0,
        })

    return ok(students=students)


@require_GET
@admin_only
def api_admin_tutors(request):
    tutors = User.objects.filter(role="tutor", is_active=True).annotate(
        session_count=Count("tutor_requests_received", filter=Q(tutor_requests_received__status="accepted")),
        student_count=Count("tutor_requests_received__student", filter=Q(tutor_requests_received__status="accepted"), distinct=True),
        pending_requests=Count("tutor_requests_received", filter=Q(tutor_requests_received__status="pending")),
    )

    data = [
        {
            **user_json(t),
            "sessions": t.session_count,
            "students": t.student_count,
            "pending_requests": t.pending_requests,
            "rating": 4.7,
        }
        for t in tutors
    ]
    return ok(tutors=data)


@require_GET
@admin_only
def api_admin_belts(request):
    result = []
    for belt_id in BELT_ORDER:
        agg = TrainingSession.objects.filter(belt_id=belt_id).aggregate(
            pass_rate=Avg("passed"),
            avg_acc=Avg("accuracy"),
            avg_time=Avg("time_used"),
        )
        holders = BeltProgress.objects.filter(belt_id=belt_id, passed=True).count()
        result.append({
            "belt_id":      belt_id,
            "holders":      holders,
            "pass_rate":    round((agg["pass_rate"] or 0) * 100, 1),
            "avg_accuracy": round((agg["avg_acc"] or 0) * 100, 1),
            "avg_time_secs": round(agg["avg_time"] or 0, 1),
        })
    return ok(belt_analytics=result)


@require_GET
@admin_only
def api_admin_knowledge(request):
    facts = FactMemory.objects.values("a", "b").annotate(
        total_seen=Sum("seen"),
        total_correct=Sum("correct"),
        avg_time=Avg("total_time_ms"),
    ).filter(total_seen__gt=0)

    data = [
        {
            "a":        f["a"],
            "b":        f["b"],
            "seen":     f["total_seen"],
            "correct":  f["total_correct"],
            "avg_time": round(f["avg_time"] or 0, 0),
        }
        for f in facts
    ]
    return ok(facts=data)


@require_GET
@admin_only
def api_admin_activity(request):
    sessions = TrainingSession.objects.select_related("user").order_by("-created_at")[:80]
    data = [
        {
            "id":           s.pk,
            "student_name": s.user.get_full_name(),
            "school":       s.user.school,
            "county":       s.user.county,
            "belt_id":      s.belt_id,
            "passed":       s.passed,
            "accuracy":     round(s.accuracy * 100, 1),
            "time_used":    s.time_used,
            "total_q":      s.total_q,
            "correct":      s.correct,
            "created_at":   s.created_at.isoformat(),
        }
        for s in sessions
    ]
    return ok(sessions=data)


@require_GET
@admin_only
def api_admin_county(request):
    rows = (
        User.objects
        .filter(role="student", is_active=True)
        .exclude(county="")
        .values("county")
        .annotate(students=Count("id"), paid_count=Sum("is_paid"))
        .order_by("-students")
    )
    data = [
        {
            "county":   r["county"],
            "students": r["students"],
            "revenue":  (r["paid_count"] or 0) * 5,
        }
        for r in rows
    ]
    return ok(counties=data)


@require_GET
@admin_only
def api_admin_leaderboard(request):
    qs = (
        User.objects
        .filter(role="student", is_active=True)
        .annotate(score=Sum("training_sessions__correct"))
        .order_by(F("score").desc(nulls_last=True))[:50]
    )
    entries = [
        {
            "id":    u.pk,
            "name":  u.get_full_name(),
            "school": u.school,
            "county": u.county,
            "score":  u.score or 0,
        }
        for u in qs
    ]
    return ok(entries=entries)


@require_GET
@admin_only
def api_admin_tutor_requests(request):
    reqs = TutorRequest.objects.select_related("student", "tutor").order_by("-created_at")
    data = [
        {
            "id":           r.pk,
            "student_name": r.student.get_full_name(),
            "tutor_name":   r.tutor.get_full_name(),
            "school":       r.student.school,
            "county":       r.student.county,
            "status":       r.status,
            "created_at":   r.created_at.isoformat(),
        }
        for r in reqs
    ]
    return ok(requests=data)


@csrf_exempt
@require_POST
@admin_only
def api_admin_suspend(request):
    data = json_body(request)
    uid  = data.get("user_id")
    User.objects.filter(pk=uid).update(is_active=False)
    return ok()


@csrf_exempt
@require_POST
@admin_only
def api_admin_upgrade(request):
    data = json_body(request)
    uid  = data.get("user_id")
    paid = bool(data.get("paid", True))
    User.objects.filter(pk=uid).update(is_paid=paid)
    return ok()


@csrf_exempt
@require_POST
@admin_only
def api_admin_approve_tutor(request):
    data = json_body(request)
    uid  = data.get("user_id")
    # is_paid doubles as "verified" for tutors
    User.objects.filter(pk=uid, role="tutor").update(is_paid=True)
    return ok()
